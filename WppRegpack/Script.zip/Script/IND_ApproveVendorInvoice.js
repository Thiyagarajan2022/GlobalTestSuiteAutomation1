﻿//USEUNIT ReportUtils
//USEUNIT TextUtils
function todo(lvl,apLvl){ 
aqUtils.Delay(5000, Indicator.Text);
Client_Managt = Aliases.Maconomy.Shell.Composite.Composite.Composite.Composite2.Composite.Composite.Composite.Composite.Composite.PTabFolder.Composite.McClumpSashForm.Composite.Composite.ToDoList;
if(apLvl==0){
if(lvl==3){ 
Client_Managt.ClickItem("|Approve Invoice Allocation Line (Substitute) (*)");
ReportUtils.logStep_Screenshot(); 
Client_Managt.DblClickItem("|Approve Invoice Allocation Line (Substitute) (*)");
TextUtils.writeLog("Entering into Approve Invoice Allocation Line (Substitute) from To-Dos List");
}
if(lvl==2){
Client_Managt.ClickItem("|Approve Invoice Allocation Line (*)");
ReportUtils.logStep_Screenshot(); 
Client_Managt.DblClickItem("|Approve Invoice Allocation Line (*)");
TextUtils.writeLog("Entering into Approve Invoice Allocation Line from To-Dos List");
}
}
else{ 
if(lvl==3){
Client_Managt.ClickItem("|Approve Invoice Allocation Line by Type (Substitute) (*)");
ReportUtils.logStep_Screenshot(); 
Client_Managt.DblClickItem("|Approve Invoice Allocation Line by Type (Substitute) (*)");
TextUtils.writeLog("Entering into Approve Invoice Allocation Line by Type (Substitute) from To-Dos List");
}
if(lvl==2){
Client_Managt.ClickItem("|Approve Invoice Allocation Line by Type (*)");
ReportUtils.logStep_Screenshot(); 
Client_Managt.DblClickItem("|Approve Invoice Allocation Line by Type (*)");
TextUtils.writeLog("Entering into Approve Invoice Allocation Line by Type from To-Dos List");
}
}
}