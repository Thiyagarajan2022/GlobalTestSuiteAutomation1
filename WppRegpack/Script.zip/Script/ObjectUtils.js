﻿//USEUNIT WorkspaceUtils


// Workspace Client
function Workspace_Client_Object(Maconomy_ParentAddress){
  var Workspace_Client = eval(Maconomy_ParentAddress).SWTObject("Composite", "").SWTObject("Composite", "", 3).SWTObject("Composite", "").SWTObject("Composite", "", 4).SWTObject("PTabFolder", "").SWTObject("TabFolderPanel", "", 1).SWTObject("TabControl", "", 4);
  return Workspace_Client;
}